##Direct survey calculation for single ages

#Set working directory
setwd("/..../")
#See https://dhsprogram.com/pubs/pdf/DHSG1/Guide_to_DHS_Statistics_DHS-7_v2.pdf page 1.36

library(foreign)
library(survey)
library(dplyr)
library(plyr)
library(tidyverse)
library(lubridate)
library(summarytools)

#Set file path to save plots
filePathPlot <- "/.../"

#Load the data
data1 <- read.dta("Data/CIKR81FL.DTA", convert.factors=FALSE) #DHS children's recode

#Age in months calculation
data1 <- data1 %>% 
  mutate(b_date = make_date(b2,b1,b17), 
         i_date = make_date(v007,v006,v016),
         age_at_int_days = difftime(i_date,b_date, units = "days"),
         age_at_int_years = floor(age_at_int_days/365.25),
         age_at_int_month = floor(age_at_int_days/30.4375)) 

data <- data1
data$age.m2 = as.numeric(data1$age_at_int_month)

#Change age range as appropriate, i.e., 9-11m, 12-23m and 24-35m
dta <- subset(data, b5==1 & age.m2 >=12 & age.m2 <=23) #Children alive and age 12 - 23m
#dta <- subset(data, b8==1 & b5==1) b8==1 - 12-23m, b8==2, 24-35m


#Create national level ID variable
dta$ID_1 <- rep(1, nrow(dta))

#Measles vaccination status
dta$measles <- ifelse(dta$h9==1|dta$h9==2|dta$h9==3,1,0)


######Weighted calculations
DHSdesign <- svydesign(id = dta$v021, strata=dta$v023, weights = dta$v005/1000000, data=dta)
options("survey.lonely.psu" = "remove") ## To avoid errors from lonely PSUs

#Tabulate at the national level - 1st set of functions
u1 <- svymean(~measles, DHSdesign, na.rm=TRUE); u1

#Tabulate at the national level - 2nd set of functions
u2 <- svyby(~measles, ~ID_1, DHSdesign, svymean, vartype=c("se","ci"), na.rm=TRUE); u2

#Tabulate by region
u3 <- svyby(~measles, ~v024, DHSdesign, svymean, vartype=c("se","ci"), na.rm=TRUE); u3



#Unweighted calculations
#Change age range as appropriate
dta <- subset(data, b5==1 & age.m2 >=12 & age.m2 <=23) 

#Create national level ID variable
dta$ID_1 <- rep(1,nrow(dta))

#Measles vaccination status
dta$measles <- ifelse(dta$h9==1|dta$h9==2|dta$h9==3,1,0)

#Some functions
mm <- function(x) mean(x, na.rm=TRUE)     #Same as sum(x)/length(x)
ss <- function(x) {p = sum(x)/length(x); return(sqrt((p*(1-p))/length(x)))} #For std dev
conf <- function(x) {
  p = sum(x)/length(x)
  sd.p <- sqrt((p*(1-p))/length(x))
  confint<- c(p-1.96*sd.p, p+1.96*sd.p) #1.96 for 95% CI
  return(data.frame(confint))
}


#Tabulate at the national level
ddply(dta,~ID_1,summarise, mean=mm(measles))
ddply(dta,~ID_1,summarise, sd=ss(measles))
ddply(dta,~ID_1,summarise, lower=conf(measles)[1,], upper=conf(measles)[2,])


#Tabulate indicator by region
ddply(dta,~v024,summarise, mean=mm(measles))
ddply(dta,~v024,summarise, sd=ss(measles))
ddply(dta,~v024,summarise, lower=conf(measles)[1,], upper=conf(measles)[2,])







