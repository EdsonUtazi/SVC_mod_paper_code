###MODsvc1 - departmental level estimation

#Set working directory
setwd("/..../")

# Load libraries
library(maps)
library(raster)
library(boot)
library(ggplot2)
library(sf)
library(terra)
library(tidyterra) 
library(tidyr)
library(scales)
library(dplyr)
library(INLA)
library(inlabru)
library(fmesher)

#Set file paths
filePathData <- "Data/"
filePathShp <- "Data/Shape Files/"
filePathRaster <- "Data/Raster Files/"
filePathResult <- "Results/SVC/"

#Loading the data
dat <- read.csv(paste0(filePathData,"data.csv"), header=TRUE)

#Rows of data with at least one missing covariate value
del <- numeric(nrow(dat))
for (i in 1:nrow(dat)){
  if (any(is.na(dat[i,18:29]))) del[i] <- i  
}

#Delete rows with missing covariate values
if (length(which(del!=0))>0) dat <- dat[-which(del!=0),]    
names(dat)

#Names of covariates
covnames <- names(dat)[c(15, 18:29)]


#Model matrix
#Observation points
X0 <- model.matrix(~ -1 + factor(urban1_rural0) + 
                     CIV_MODIS_16day_MidInfr_mean_2017_2021_1km_scaled +
                     civ_avg_wetdays_2017_2021_1km +
                     civ_dst_UCDP_2016_2020_1km +
                     civ_elevation_1km +
                     civ_UrbanAccessibility_2015_1km_filled +
                     civ_2020_walking_tt_1km +
                     civ_avg_malaria_prev_2017_2020_1km +
                     civ_avg_tmax_2017_2021_1km +
                     educ.prop +
                     health_card_doc.prop +
                     media.prop +
                     wealth.prop, 
                   data = dat)

Xobs <-  as.data.frame(X0[,-which(colnames(X0)%in%c("factor(urban1_rural0)0"))])

colnames(Xobs) <- c("urban",
                    "modis_infr",
                    "wetdays",
                    "dst_ucdp",
                    "elevation",
                    "urban_access",
                    "walking_tt",
                    "malaria_prev",
                    "tmax",
                    "educ",
                    "health_card",
                    "media",
                    "wealth")

names(Xobs)

ddata <- data.frame(Xobs, 
                    lon = dat$Longitude, lat = dat$Latitude, 
                    r.id = dat$DHSCLUST,
                    y = dat$received_measles, 
                    n = 1, 
                    age_9_11m2=dat$age_9_11m2,  
                    age_12_23m2=dat$age_12_23m2, 
                    age_24_35m2=dat$age_24_35m2) 

ddata <- na.omit(ddata)
names(ddata)



## Build Mesh
## Read Shape file National Boundary
shp_civ  <- st_read(paste0(filePathShp,"civ_adm0.shp"))
plot(shp_civ)

coords <- dplyr::distinct(data.frame(lon=ddata$lon, lat=ddata$lat))
nrow(coords)

meshfit <- fm_mesh_2d_inla(loc = coords,
                           boundary = shp_civ, 
                           max.edge = c(0.1, 0.5),
                           offset = c(0.1, 0.5),
                           cutoff = 0.1)

meshfit$n 
plot(meshfit)
points(coords, col = "red", pch = 16)

#Convert ddata to an sf object
ddata <- st_as_sf(ddata, coords = c("lon", "lat"), crs = st_crs(shp_civ))

#SPDE object
nu <- 1 # Matern smoothness parameter, redundant here as it implies alpha=2
alpha <- 2

#r0 - this is 5% of the extent of CIV in the north-south direction (i.e. 0.05*(ymax-ymin))
ymax <- max(coords[,2])
ymin <- min(coords[,2])
r0 <- 0.05*(ymax-ymin) 

spde <- inla.spde2.pcmatern(mesh=meshfit, alpha=alpha, prior.range=c(r0, 0.01), prior.sigma=c(3, 0.01))

# Priors
hyper.prec = list(theta = list(prior = "pc.prec", param = c(3,0.01)))
control.fixed = list(mean = 0, prec = 1/1000, mean.intercept = 0, prec.intercept = 1/1000)  

#Formula
components <- ~ Intercept(1) +
  x(cbind(urban,
          modis_infr,
          wetdays,
          dst_ucdp,
          elevation,
          urban_access,
          walking_tt,
          malaria_prev,
          tmax,
          educ,
          health_card,
          media,
          wealth,
          age_12_23m2, 
          age_24_35m2), model = "fixed") +
  beta_1(geometry, weights= age_12_23m2, model=spde) +
  beta_2(geometry, weights= age_24_35m2, model=spde) +
  f.spat(geometry, model = spde) +
  f.iid(r.id, model = "iid", hyper = hyper.prec)

# Define the formula for the likelihood
formula <- y ~ .

# Verify dataset structure
print(head(ddata))         
print(names(ddata))        

# Fit the model using inlabru
res <- bru(
  components,
  like(
    formula = formula,
    family = "binomial",
    Ntrials = n,
    data = ddata
  ),
  options = list(
    control.fixed = control.fixed,
    control.compute = list(waic = TRUE, cpo = TRUE, dic = TRUE),
    control.inla = list(int.strategy = "eb"),
    verbose = FALSE
  )
)

# Display the summary of the results
summary(res)


##==============================================================================

#Prediction data
urban1_rural0  <- raster(paste0(filePathRaster,"CIV_urban_rural_1km.tif"))
modis_infr <- raster(paste0(filePathRaster,"CIV_MODIS_16day_MidInfr_mean_2017_2021_1km_scaled.tif"))
wetdays <- raster(paste0(filePathRaster, "civ_avg_wetdays_2017_2021_1km.tif"))
dst_ucdp <- raster(paste0(filePathRaster, "civ_dst_UCDP_2016_2020_1km.tif"))
elevation <- raster(paste0(filePathRaster, "civ_elevation_1km.tif"))
urban_access <- raster(paste0(filePathRaster, "civ_UrbanAccessibility_2015_1km_filled.tif"))
walking_tt <- raster(paste0(filePathRaster, "civ_2020_walking_tt_1km.tif"))
malaria_prev <- raster(paste0(filePathRaster, "civ_avg_malaria_prev_2017_2020_1km.tif"))
tmax <- raster(paste0(filePathRaster, "civ_avg_tmax_2017_2021_1km.tif"))
educ <- raster(paste0(filePathRaster, "civ_educkrig.tif"))
health_card <- raster(paste0(filePathRaster, "civ_health_card_dockrig.tif"))
media <- raster(paste0(filePathRaster, "civ_mediakrig.tif"))
wealth <- raster(paste0(filePathRaster, "civ_wealthkrig.tif"))
pop <- raster(paste0(filePathRaster, "civ_ppp_under5_2021_1km_filled.tif"))  

urban <- getValues(urban1_rural0)
modis_infr_values <- getValues(modis_infr)
wetdays_values <- getValues(wetdays)
dst_ucdp_values <- getValues(dst_ucdp)
elevation_values <- getValues(elevation)
urban_access_values <- getValues(urban_access)
walking_tt_values <- getValues(walking_tt)
malaria_prev_values <- getValues(malaria_prev)
tmax_values <- getValues(tmax)
educ_values <- getValues(educ)
health_card_values <- getValues(health_card)
media_values <- getValues(media)
wealth_values <- getValues(wealth)
pop_values <- getValues(pop)


#Prediction coordinates
p.coords <- raster(paste0(filePathRaster,"CIV_urban_rural_1km.tif"))
p.coords <- coordinates(p.coords)

pred_covs <- data.frame(urban, 
                        modis_infr_values,
                        wetdays_values,
                        dst_ucdp_values,
                        elevation_values,
                        urban_access_values,
                        walking_tt_values,
                        malaria_prev_values,
                        tmax_values,
                        educ_values,
                        health_card_values,
                        media_values,
                        wealth_values,
                        pop_values)

#Predict only for non-missing grid cells
ind <- apply(pred_covs, 1, function(x) any(is.na(x)))
miss    <- which(ind==TRUE)
nonmiss <- which(ind==FALSE)
pred_covs <- pred_covs[nonmiss, ]
pop <- pred_covs[,"pop_values"] #Population weighting layer

#Prediction model matrix
X0 <- model.matrix(~ -1 + factor(urban) + 
                     modis_infr_values +
                     wetdays_values +
                     dst_ucdp_values +
                     elevation_values +
                     urban_access_values +
                     walking_tt_values +
                     malaria_prev_values +
                     tmax_values +
                     educ_values +
                     health_card_values +
                     media_values +
                     wealth_values, data = pred_covs)

Xpred <-  as.data.frame(X0[,-which(colnames(X0)%in%c("factor(urban)0"))])

colnames(Xpred) <- c("urban", 
                     "modis_infr",
                     "wetdays",
                     "dst_ucdp",
                     "elevation",
                     "urban_access",
                     "walking_tt",
                     "malaria_prev",
                     "tmax",
                     "educ",
                     "health_card",
                     "media",
                     "wealth")


## DHSCLUST ID Maximum value
max(unique(dat$DHSCLUST))  ##539


###For departmental level estimation (adm3)
coord.p <- data.frame(lon = p.coords[nonmiss,1], lat = p.coords[nonmiss,2])
spol1   <- st_read(paste0(filePathShp,"civ_departments_adm.shp"))
# Convert to sp 
adm1_sp <- as(st_geometry(spol1), "Spatial")
crs_adm1 <- st_crs(spol1)$proj4string
points_sp <- SpatialPoints(coord.p, proj4string = CRS(crs_adm1))

sp.1 <- rep(NA, nrow(coord.p))
for(i in seq_along(adm1_sp)) {
  idx <- which(!is.na(over(points_sp, adm1_sp[i])))
  sp.1[idx] <- i
}


#Generate predictions
#For 9-11m  
dpred <- data.frame(Xpred, lon = p.coords[nonmiss,1], lat = p.coords[nonmiss,2], 
                    age_12_23m2 = 0, 
                    age_24_35m2 = 0,
                    r.id = 540:(539 + nrow(Xpred))  
) 

dpred <- st_as_sf(dpred, coords = c("lon", "lat"), crs = st_crs(shp_civ))

n.samples <- 1000
iid.sd <- sqrt(1/res$summary.hyperpar["Precision for f.iid", 1])
iid.samp <- matrix(rnorm(nrow(dpred)*n.samples, 0, iid.sd), nrow=nrow(dpred), ncol=n.samples)
ssamp <- generate(res, dpred,
                  ~ Intercept + x + f.spat, 
                  n.samples = n.samples)
inv.linpred <- inv.logit(ssamp + iid.samp)


#District level prediction 
dd    <- 1:nrow(spol1)
dd.un <- unique(sp.1)
dmiss <- which(!dd%in%dd.un)

if (length(dmiss)>0) dd_num <- dd[-dmiss]
if (length(dmiss)==0) dd_num <- dd

dist_out <- matrix(0, length(dd_num), 5)
for (i in 1:length(dd_num)){
  if (length(which(sp.1==dd_num[i]))==1){
    pop.ext <- pop[which(sp.1==dd_num[i])]
    ext <- as.vector(sapply(inv.linpred[which(sp.1==dd_num[i]),], FUN=function(x) weighted.mean(x, w=pop.ext, na.rm=TRUE)))
  }
  if (length(which(sp.1==dd_num[i]))>1){
    pop.ext <- pop[which(sp.1==dd_num[i])]
    ext <- as.vector(apply(inv.linpred[which(sp.1==dd_num[i]),], 2, FUN=function(x) weighted.mean(x, w=pop.ext, na.rm=TRUE)))
  }
  
  dist_out[i,] <- as.vector(c(mean(ext), sd(ext), quantile(ext, probs=c(0.025,0.5,0.975))))
}

dist_out <- cbind(dd_num, dist_out)
colnames(dist_out) <- c("ID", "mean", "sd", "0.025quant", "0.5quant", "0.975quant")


#The district-level estimates will have the same ordering as in the shapefile if they have the same no of areas
write.csv(dist_out, paste0(filePathResult, "District_estimates_mcv1_9_11.csv"))



#For 12-23m 
dpred <- data.frame(Xpred, lon = p.coords[nonmiss,1], lat = p.coords[nonmiss,2], 
                    age_12_23m2 = 1, 
                    age_24_35m2 = 0,
                    r.id = 540:(539 + nrow(Xpred))  
) 
dpred <- st_as_sf(dpred, coords = c("lon", "lat"), crs = st_crs(shp_ng))

n.samples <- 1000
iid.sd <- sqrt(1/res$summary.hyperpar["Precision for f.iid", 1])
iid.samp <- matrix(rnorm(nrow(dpred)*n.samples, 0, iid.sd), nrow=nrow(dpred), ncol=n.samples)
ssamp <- generate(res, dpred,
                  ~ Intercept + x + f.spat + alpha_2, 
                  n.samples = n.samples)
inv.linpred <- inv.logit(ssamp + iid.samp)

#District level prediction 
dd    <- 1:nrow(spol1)
dd.un <- unique(sp.1)
dmiss <- which(!dd%in%dd.un)

if (length(dmiss)>0) dd_num <- dd[-dmiss]
if (length(dmiss)==0) dd_num <- dd

dist_out <- matrix(0, length(dd_num), 5)
for (i in 1:length(dd_num)){
  if (length(which(sp.1==dd_num[i]))==1){
    pop.ext <- pop[which(sp.1==dd_num[i])]
    ext <- as.vector(sapply(inv.linpred[which(sp.1==dd_num[i]),], FUN=function(x) weighted.mean(x, w=pop.ext, na.rm=TRUE)))
  }
  if (length(which(sp.1==dd_num[i]))>1){
    pop.ext <- pop[which(sp.1==dd_num[i])]
    ext <- as.vector(apply(inv.linpred[which(sp.1==dd_num[i]),], 2, FUN=function(x) weighted.mean(x, w=pop.ext, na.rm=TRUE)))
  }
  
  dist_out[i,] <- as.vector(c(mean(ext), sd(ext), quantile(ext, probs=c(0.025,0.5,0.975))))
}

dist_out <- cbind(dd_num, dist_out)
colnames(dist_out) <- c("ID", "mean", "sd", "0.025quant", "0.5quant", "0.975quant")

#The district-level estimates will have the same ordering as in the shapefile if they have the same no of areas
write.csv(dist_out, paste0(filePathResult, "District_estimates_mcv1_12_23.csv"))



#For 24-35m 
dpred <- data.frame(Xpred, lon = p.coords[nonmiss,1], lat = p.coords[nonmiss,2], 
                    age_12_23m2 = 0, 
                    age_24_35m2 = 1,
                    r.id = 540:(539 + nrow(Xpred))  
) 
dpred <- st_as_sf(dpred, coords = c("lon", "lat"), crs = st_crs(shp_ng))

n.samples <- 1000
iid.sd <- sqrt(1/res$summary.hyperpar["Precision for f.iid",1])
iid.samp <- matrix(rnorm(nrow(dpred)*n.samples, 0, iid.sd), nrow=nrow(dpred), ncol=n.samples)
ssamp <- generate(res, dpred,
                  ~ Intercept + x + f.spat + alpha_3, 
                  n.samples = n.samples)

inv.linpred <- inv.logit(ssamp + iid.samp) 

#District level prediction 
dd    <- 1:nrow(spol1)
dd.un <- unique(sp.1)
dmiss <- which(!dd%in%dd.un)

if (length(dmiss)>0) dd_num <- dd[-dmiss]
if (length(dmiss)==0) dd_num <- dd

dist_out <- matrix(0, length(dd_num), 5)
for (i in 1:length(dd_num)){
  if (length(which(sp.1==dd_num[i]))==1){
    pop.ext <- pop[which(sp.1==dd_num[i])]
    ext <- as.vector(sapply(inv.linpred[which(sp.1==dd_num[i]),], FUN=function(x) weighted.mean(x, w=pop.ext, na.rm=TRUE)))
  }
  if (length(which(sp.1==dd_num[i]))>1){
    pop.ext <- pop[which(sp.1==dd_num[i])]
    ext <- as.vector(apply(inv.linpred[which(sp.1==dd_num[i]),], 2, FUN=function(x) weighted.mean(x, w=pop.ext, na.rm=TRUE)))
  }
  
  dist_out[i,] <- as.vector(c(mean(ext), sd(ext), quantile(ext, probs=c(0.025,0.5,0.975))))
}

dist_out <- cbind(dd_num, dist_out)
colnames(dist_out) <- c("ID", "mean", "sd", "0.025quant", "0.5quant", "0.975quant")


#The district-level estimates will have the same ordering as in the shapefile if they have the same no of areas
write.csv(dist_out, paste0(filePathResult, "District_estimates_mcv1_24_35.csv"))





####For plotting - point estimates
adm <- readShapePoly(paste0(filePathShp,"civ_departments_adm.shp"))
out9_11 <- read.csv(paste0(filePathResult, "District_estimates_mcv1_9_11.csv"))
out12_23 <- read.csv(paste0(filePathResult, "District_estimates_mcv1_12_23.csv"))
out24_35 <- read.csv(paste0(filePathResult, "District_estimates_mcv1_24_35.csv"))

adm$mean_9_11 <- out9_11$mean*100
adm$mean_12_23 <- out12_23$mean*100
adm$mean_24_35 <- out24_35$mean*100

#Convert to sf object
adm_asf <- st_as_sf(adm)

p1 <- ggplot(adm_asf) + geom_sf(aes(fill = mean_9_11)) + ggtitle("9 - 11 months") +
  viridis::scale_fill_viridis(discrete = FALSE,direction=-1, name="% vaccinated", option="viridis", limits=c(40,100)) +
  theme_bw() + theme(plot.margin = unit(c(0,0,0,0), "cm")) + labs(x="Longitude", y="Latitude") +
  annotate(geom="text", x=-2, y=11, label="", size=4.5, fontface="bold") +
  theme(panel.border = element_blank(), axis.ticks = element_blank(),
        plot.title = element_text(hjust = 0.5)) + theme(legend.position="none") +
  scale_x_continuous(label = abs) + scale_y_continuous(label = abs)

p2 <- ggplot(adm_asf) + geom_sf(aes(fill = mean_12_23)) + ggtitle("12 - 23 months") +
  viridis::scale_fill_viridis(discrete = FALSE,direction=-1, name="% vaccinated", option="viridis", limits=c(40,100)) +
  theme_bw() + theme(plot.margin = unit(c(0,0,0,0), "cm")) + labs(x="Longitude", y="Latitude") +
  annotate(geom="text", x=-2, y=11, label="", size=4.5, fontface="bold") +
  theme(panel.border = element_blank(), axis.ticks = element_blank(),
        plot.title = element_text(hjust = 0.5)) + theme(legend.position="none") +
  scale_x_continuous(label = abs) + scale_y_continuous(label = abs)

p3 <- ggplot(adm_asf) + geom_sf(aes(fill = mean_24_35)) + ggtitle("24 - 35 months") +
  viridis::scale_fill_viridis(discrete = FALSE,direction=-1, name="% vaccinated", option="viridis", limits=c(40,100)) +
  theme_bw() + theme(plot.margin = unit(c(0,0,0,0), "cm")) + labs(x="Longitude", y="Latitude") +
  annotate(geom="text", x=-2, y=11, label="", size=4.5, fontface="bold") +
  theme(panel.border = element_blank(), axis.ticks = element_blank(),
        plot.title = element_text(hjust = 0.5)) + #theme(legend.position="none") +
  scale_x_continuous(label = abs) + scale_y_continuous(label = abs)

ll <- get_legend(p3)
p3 <- p3 + theme(legend.position = "none")

pp <- ggpubr::ggarrange(p1, p2, p3, ll, ncol = 4,nrow = 1, widths=c(1,1,1,0.5))
pp

ggsave(filename= paste0(filePathResult, "dist_plot_mcv1.png"), plot=pp, height=6, width=12, units="in", device = "png", dpi=300)


####For plotting - 95% CI width
adm <- st_read(paste0(filePathShp,"civ_departments_adm.shp"))
out9_11 <- read.csv(paste0(filePathResult, "District_estimates_mcv1_9_11.csv"))
out12_23 <- read.csv(paste0(filePathResult, "District_estimates_mcv1_12_23.csv"))
out24_35 <- read.csv(paste0(filePathResult, "District_estimates_mcv1_24_35.csv"))

adm$ci_9_11 <- (out9_11$X0.975quant - out9_11$X0.025quant)*100
adm$ci_12_23 <- (out12_23$X0.975quant - out12_23$X0.025quant)*100
adm$ci_24_35 <- (out24_35$X0.975quant - out24_35$X0.025quant)*100

#Convert to sf object
adm_asf <- st_as_sf(adm)

p1 <- ggplot(adm_asf) + geom_sf(aes(fill = ci_9_11)) + ggtitle("9 - 11 months") +
  viridis::scale_fill_viridis(discrete = FALSE,direction=-1, name="95% CI \nwidth", option="cividis", limits=c(13,35)) +
  theme_bw() + theme(plot.margin = unit(c(0,0,0,0), "cm")) + labs(x="Longitude", y="Latitude") +
  annotate(geom="text", x=-2, y=11, label="", size=4.5, fontface="bold") +
  theme(panel.border = element_blank(), axis.ticks = element_blank(),
        plot.title = element_text(hjust = 0.5)) + theme(legend.position="none") +
  scale_x_continuous(label = abs) + scale_y_continuous(label = abs)

p2 <- ggplot(adm_asf) + geom_sf(aes(fill = ci_12_23)) + ggtitle("12 - 23 months") +
  viridis::scale_fill_viridis(discrete = FALSE,direction=-1, name="95% CI \nwidth", option="cividis", limits=c(13,35)) +
  theme_bw() + theme(plot.margin = unit(c(0,0,0,0), "cm")) + labs(x="Longitude", y="Latitude") +
  annotate(geom="text", x=-2, y=11, label="", size=4.5, fontface="bold") +
  theme(panel.border = element_blank(), axis.ticks = element_blank(),
        plot.title = element_text(hjust = 0.5)) + theme(legend.position="none") +
  scale_x_continuous(label = abs) + scale_y_continuous(label = abs)

p3 <- ggplot(adm_asf) + geom_sf(aes(fill = ci_24_35)) + ggtitle("24 - 35 months") +
  viridis::scale_fill_viridis(discrete = FALSE,direction=-1, name="95% CI \nwidth", option="cividis", limits=c(13,35)) +
  theme_bw() + theme(plot.margin = unit(c(0,0,0,0), "cm")) + labs(x="Longitude", y="Latitude") +
  annotate(geom="text", x=-2, y=11, label="", size=4.5, fontface="bold") +
  theme(panel.border = element_blank(), axis.ticks = element_blank(),
        plot.title = element_text(hjust = 0.5)) + #theme(legend.position="none") +
  scale_x_continuous(label = abs) + scale_y_continuous(label = abs)

ll <- get_legend(p3)
p3 <- p3 + theme(legend.position = "none")

pp <- ggpubr::ggarrange(p1, p2, p3, ll, ncol = 4, nrow = 1, widths=c(1,1,1,0.5))
pp

ggsave(filename= paste0(filePathResult, "dist_plot_mcv1_ci.png"), plot=pp, height=6, width=12, units="in", device = "png", dpi=300)



