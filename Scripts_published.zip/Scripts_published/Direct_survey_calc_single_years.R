##Direct survey calculation for single ages

#Set working directory
setwd("/............/")
#See https://dhsprogram.com/pubs/pdf/DHSG1/Guide_to_DHS_Statistics_DHS-7_v2.pdf page 1.36

library(foreign)
library(survey)
library(dplyr)
library(plyr)
library(tidyverse)
library(lubridate)
library(summarytools)

#Set file path to save plots
filePathPlot <- "/.../"

#Load the data
data1 <- read.dta("Data/CIKR81FL.DTA", convert.factors=FALSE) #DHS children's recode

#Age in months calculation
data1 <- data1 %>% 
  mutate(b_date = make_date(b2,b1,b17), 
         i_date = make_date(v007,v006,v016),
         age_at_int_days = difftime(i_date,b_date, units = "days"),
         age_at_int_years = floor(age_at_int_days/365.25),
         age_at_int_month = floor(age_at_int_days/30.4375)) 

data <- data1
data$age.m2 = as.numeric(data1$age_at_int_month)

dta <- subset(data, b5==1 & age.m2 >=9 & age.m2 <=35) #Children alive and age 9 - 35m
summary(dta$age.m2)

#Create national level ID variable
dta$ID_1 <- rep(1, nrow(dta))

#Measles vaccination status
dta$measles <- ifelse(dta$h9==1|dta$h9==2|dta$h9==3,1,0)

#Start loop here
ages <- 9:35

######Weighted calculations

#Output matrix
out <- matrix(0, nrow=length(ages), ncol=6)

for (kk in ages){
  dta1 <- subset(dta, age.m2 == kk) 
  
  # Complex sample design parameters
  #v021 is the cluster id not the case id
  #Seen id= ~~v002+caseid
  DHSdesign <- svydesign(id = dta1$v021, strata=dta1$v023, weights = dta1$v005/1000000, data=dta1)
  options("survey.lonely.psu" = "remove") ## To avoid errors from lonely PSUs
  
  #Tabulate at the national level - 1st set of functions
  u1 <- svymean(~measles, DHSdesign, na.rm=TRUE); u1
  
  #Tabulate at the national level - 2nd set of functions
  u2 <- svyby(~measles, ~ID_1, DHSdesign, svymean, vartype=c("se","ci"), na.rm=TRUE); u2
  
  out[kk-8,] <- c(kk, as.numeric(u2))
}

colnames(out) <- c("age", "ID1", "mean", "se", "ci_l", "ci_u")
out



######Unweighted calculations

dta <-  subset(data, b5==1 & age.m2 >=9 & age.m2 <=35)

#Create national level ID variable
dta$ID_1 <- rep(1,nrow(dta))

#Percentage vaccinated against measles
dta$measles <- ifelse(dta$h9==1|dta$h9==2|dta$h9==3,1,0)

# Create weight variable
dta$wt <- dta$v005/1000000

#Some functions
mm <- function(x) mean(x, na.rm=TRUE)     
ss <- function(x) {p = sum(x)/length(x); return(sqrt((p*(1-p))/length(x)))} #For std dev
conf <- function(x) {
  p = sum(x)/length(x)
  sd.p <- sqrt((p*(1-p))/length(x))
  confint<- c(p-1.96*sd.p, p+1.96*sd.p) #1.96 for 95% CI
  return(data.frame(confint))
}


#Start loop here
ages <- 9:35
out2 <- matrix(0, nrow=length(ages), ncol=5)

for (kk in ages){
  
  dta1 <- subset(dta, age.m2 == kk)
  #Tabulate at the national level
  u1 <- ddply(dta1,~ID_1,summarise, mean=mm(measles))
  u2 <- ddply(dta1,~ID_1,summarise, sd=ss(measles))
  u3 <- ddply(dta1,~ID_1,summarise, lower=conf(measles)[1,], upper=conf(measles)[2,])
  
  out2[kk-8,] <- c(kk, u1$mean, u2$sd, u3$lower, u3$upper)
}

colnames(out2) <- c("age", "mean", "se", "ci_l", "ci_u")
out2
out <- data.frame(out)
out2 <- data.frame(out2)

out3 <- data.frame(age = c(out2$age, out$age), mean = c(out2$mean, out$mean),
                   group =c(rep("Unweighted",nrow(out)), rep("Weighted",nrow(out2))))


#For plotting
colors <- c("#481567FF", "#20A387FF")
p1 <- ggplot(out3, aes(x = age, y = mean*100, color = group)) +
  #geom_ribbon(aes(ymin = lower, ymax = upper), fill = "skyblue", alpha = 0.4) +
  geom_line(size = 1) + ylim(0.4*100,0.8*100) +
  scale_color_manual(values=colors) +
  labs(title = "",
       x = "Age (months)", y = "% vaccinated") + theme_bw() +
  theme(legend.title= element_blank(), legend.position="bottom")  
p1

ggsave(filename= paste0(filePathPlot, "Single_age_data_plot.png"), plot=p1, height=12, width=12, units="in", device = "png", dpi=300)


#Hist plot
dat <- read.csv("Updated Scripts Without 0_8 Months/Edson_outputs/bardat.csv", header = TRUE)

dat$Age_group <- as.factor(dat$Age_group)
dat$Age_group <- relevel(dat$Age_group, ref="9-11")

pd <- position_dodge(width = 0.9)
colors <- c("#481567FF", "#20A387FF")
pp <- ggplot(dat, aes(fill=Weighting, y=Vax, x=Age_group)) + 
  geom_bar(position="dodge", stat="identity") +
  scale_fill_manual(values=colors) + coord_cartesian(ylim = c(40, 80)) +
  geom_text(aes(label = Vax),
            position = pd, 
            vjust = -0.3, 
            size = 3) +
  labs(x="Age group (months)", y="% vaccinated") + 
  theme_bw() +
  theme(legend.title= element_blank(), legend.position="bottom") 
pp

ggsave(filename= paste0(filePathPlot, "Group_age_data_plot.png"), plot=pp, height=4, width=6, units="in", device = "png", dpi=300)






