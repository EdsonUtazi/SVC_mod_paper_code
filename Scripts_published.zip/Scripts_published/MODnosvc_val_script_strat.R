
###MODnosvc validation script - stratified k-fold

#Set working directory
setwd("/..../")

# libraries
library(pROC)
library(maps)
library(raster)
library(boot)
library(ggplot2)
library(sf)
library(terra)
library(tidyterra) 
library(tidyr)
library(scales)
library(dplyr)
library(INLA)
library(inlabru)
library(fmesher)

#Source CRPS function
source(paste0("CRPS_func.R"))

#Set file paths
filePathData <- "Data/"
filePathShp <- "Data/Shape Files/"
filePathRaster <- "Data/Raster Files/"
filePathResult <- "Results/SVC/"

#Loading the data
dat <- read.csv(paste0(filePathData,"data.csv"), header=TRUE)

#Rows of data with at least one missing covariate value
del <- numeric(nrow(dat))
for (i in 1:nrow(dat)){
  if (any(is.na(dat[i,18:29]))) del[i] <- i  
}

#Delete rows with missing covariate values
if (length(which(del!=0))>0) dat <- dat[-which(del!=0),]    
names(dat)

#Names of covariates
covnames <- names(dat)[c(15, 18:29)]


#Model matrix
#Observation points
X0 <- model.matrix(~ -1 + factor(urban1_rural0) + 
                     CIV_MODIS_16day_MidInfr_mean_2017_2021_1km_scaled +
                     civ_avg_wetdays_2017_2021_1km +
                     civ_dst_UCDP_2016_2020_1km +
                     civ_elevation_1km +
                     civ_UrbanAccessibility_2015_1km_filled +
                     civ_2020_walking_tt_1km +
                     civ_avg_malaria_prev_2017_2020_1km +
                     civ_avg_tmax_2017_2021_1km +
                     educ.prop +
                     health_card_doc.prop +
                     media.prop +
                     wealth.prop, 
                   data = dat)

Xobs <-  as.data.frame(X0[,-which(colnames(X0)%in%c("factor(urban1_rural0)0"))])

colnames(Xobs) <- c("urban",
                    "modis_infr",
                    "wetdays",
                    "dst_ucdp",
                    "elevation",
                    "urban_access",
                    "walking_tt",
                    "malaria_prev",
                    "tmax",
                    "educ",
                    "health_card",
                    "media",
                    "wealth")

names(Xobs)

ddata <- data.frame(Xobs, 
                    lon = dat$Longitude, lat = dat$Latitude, 
                    r.id = dat$DHSCLUST,
                    y = dat$received_measles, 
                    n = 1) 

ddata <- na.omit(ddata)
names(ddata)



## Build Mesh
## Read Shape file National Boundary
shp_civ  <- st_read(paste0(filePathShp,"civ_adm0.shp"))
plot(shp_civ)

coords <- dplyr::distinct(data.frame(lon=ddata$lon, lat=ddata$lat))
nrow(coords)

meshfit <- fm_mesh_2d_inla(loc = coords,
                           boundary = shp_civ, 
                           max.edge = c(0.1, 0.5),
                           offset = c(0.1, 0.5),
                           cutoff = 0.1)

meshfit$n 
plot(meshfit)
points(coords, col = "red", pch = 16)

#Convert ddata to an sf object
ddata <- st_as_sf(ddata, coords = c("lon", "lat"), crs = st_crs(shp_civ))

#SPDE object
nu <- 1 # Matern smoothness parameter, redundant here as it implies alpha=2
alpha <- 2

#r0 - this is 5% of the extent of CIV in the north-south direction (i.e. 0.05*(ymax-ymin))
ymax <- max(coords[,2])
ymin <- min(coords[,2])
r0 <- 0.05*(ymax-ymin) 

spde <- inla.spde2.pcmatern(mesh=meshfit, alpha=alpha, prior.range=c(r0, 0.01), prior.sigma=c(3, 0.01))

# Priors
hyper.prec = list(theta = list(prior = "pc.prec", param = c(3, 0.01)))
control.fixed = list(mean = 0, prec = 1/1000, mean.intercept = 0, prec.intercept = 1/1000) 


###############Start of k-fold cross-validation loop 
cv <- 10   #i.e. 10-fold cross validation
cl <- length(unique(dat.clust$DHSCLUST))  #unique number of clusters
lim <- floor(cl/cv)

#Stratified k-fold - subset using clusters (CHECK THAT CLUSTERS ARE SPATIALLY ARRANGED)
strat <- sort(unique(dat.clust$DHSCLUST))

nsamples <- 1000 #Number of posterior samples

#Output objects
val.out.all   <- matrix(0, cv, 1) 
val.out.9_11  <- matrix(0, cv, 4) 
val.out.12_23 <- matrix(0, cv, 4)
val.out.24_35 <- matrix(0, cv, 4)
obspred.out   <- data.frame()

for (kk in 1:cv){
  if (kk < cv) {qq <- (((kk-1)*lim)+1):(lim*kk); samp.c <- strat[qq]}
  if (kk == cv) {qq <- (((kk-1)*lim)+1):cl; samp.c <- strat[qq]}
  
  #Subset modelling and validation datasets 
  ddata.mod <- subset(ddata, !DHSCLUST%in%samp.c)
  dat.clust.val <- subset(dat.clust, DHSCLUST%in%samp.c) 
  ddata.val <- subset(ddata, DHSCLUST%in%samp.c) 
  
  #Formula
  components  <- ~ Intercept(1) + 
    x(cbind(urban,
            modis_infr,
            wetdays,
            dst_ucdp,
            elevation,
            urban_access,
            walking_tt,
            malaria_prev,
            tmax,
            educ,
            health_card,
            media,
            wealth,
            age_12_23m2, 
            age_24_35m2), model = "fixed") +
    #beta_1(geometry, weights= age_12_23m2, model=spde) +
    #beta_2(geometry, weights= age_24_35m2, model=spde) +
    f.spat(geometry, model=spde) + 
    f.iid(r.id, model="iid", hyper = hyper.prec)
  
  formula <- y ~ .  
  
  #Fit model
  res <- bru(
    components,
    like(
      formula = formula,
      family = "binomial",
      Ntrials = n,
      data = ddata.mod
    ),
    options = list(
      control.fixed = control.fixed,
      control.compute = list(waic = TRUE, cpo = TRUE, dic = TRUE),
      control.inla = list(int.strategy = "eb"),
      verbose = FALSE
    )
  )
  
  
  ####Predict out-sample 
  #Predict individual level all ages
  pred_ind_out_all <- predict(res, ddata.val, ~ inv.logit(Intercept + x + 
                                                            f.spat + f.iid),
                              n.samples = nsamples, probs = c(0.025, 0.5, 0.975))
  
  obs <- ddata.val$y
  pred <- pred_ind_out_all$mean
  bscore <- sum((pred - obs)^2)/ length(obs)
  val.out.all[kk, ] <- c(bscore)
  
  
  #Predict cluster level for age 9-11 months
  dat.clust.mod1 <- subset(dat.clust.val, agecat2 == "9-11 months")
  dat.clust.mod1$age_12_23m2 <- 0 
  dat.clust.mod1$age_24_35m2 <- 0 
  dat.clust.mod1$r.id <- dat.clust.mod1$DHSCLUST
  
  ssamp <- generate(res, dat.clust.mod1, ~ Intercept + x + f.spat, n.samples = nsamples)
  iid.sd <- sqrt(1 / res$summary.hyperpar["Precision for f.iid", 1])
  iid.samp <- matrix(rnorm(nrow(dat.clust.mod1) * nsamples, 0, iid.sd), 
                     nrow = nrow(dat.clust.mod1), ncol = nsamples)
  inv.linpred <- inv.logit(ssamp + iid.samp)
  
  pred.obs <- data.frame(t(apply(inv.linpred, 1, FUN = function(x) { 
    c(mean(x), sd(x), quantile(x, probs = c(0.025, 0.5, 0.975))) 
  })))
  colnames(pred.obs) <- c("mean", "sd", "low", "median", "up")
  
  prob.obs.val <- dat.clust.mod1$prob_obs
  prob.pred.val <- pred.obs$mean
  
  RMSE.val <- sqrt(mean((prob.pred.val - prob.obs.val)^2))
  MAE.val <- mean(abs(prob.pred.val - prob.obs.val))
  avg_bias <- mean(prob.pred.val - prob.obs.val)
  CRPS <- crps(inv.linpred, prob.obs.val)
  
  val.out.9_11[kk, ] <- c(RMSE.val, MAE.val, avg_bias, CRPS)
  
  qp1 <- data.frame(DHSCLUST = dat.clust.mod1$DHSCLUST, agegp = dat.clust.mod1$agecat2,
                    prob.obs.val, prob.pred.val, pred.obs$sd, pred.obs$low, pred.obs$up)
  
  
  #Predict cluster level for age 12-23 months
  dat.clust.mod1 <- subset(dat.clust.val, agecat2 == "12-23 months")
  dat.clust.mod1$age_12_23m2 <- 1 
  dat.clust.mod1$age_24_35m2 <- 0   
  dat.clust.mod1$r.id <- dat.clust.mod1$DHSCLUST
  
  ssamp <- generate(res, dat.clust.mod1, ~ Intercept + x + f.spat, n.samples = nsamples)
  iid.sd <- sqrt(1 / res$summary.hyperpar["Precision for f.iid", 1])
  iid.samp <- matrix(rnorm(nrow(dat.clust.mod1) * nsamples, 0, iid.sd), 
                     nrow = nrow(dat.clust.mod1), ncol = nsamples)
  inv.linpred <- inv.logit(ssamp + iid.samp)
  
  pred.obs <- data.frame(t(apply(inv.linpred, 1, FUN = function(x) { 
    c(mean(x), sd(x), quantile(x, probs = c(0.025, 0.5, 0.975))) 
  })))
  colnames(pred.obs) <- c("mean", "sd", "low", "median", "up")
  
  prob.obs.val <- dat.clust.mod1$prob_obs
  prob.pred.val <- pred.obs$mean
  
  RMSE.val <- sqrt(mean((prob.pred.val - prob.obs.val)^2))
  MAE.val <- mean(abs(prob.pred.val - prob.obs.val))
  avg_bias <- mean(prob.pred.val - prob.obs.val)
  
  CRPS <- crps(inv.linpred, prob.obs.val)
  
  val.out.12_23[kk, ] <- c(RMSE.val, MAE.val, avg_bias, CRPS)
  
  qp2 <- data.frame(DHSCLUST = dat.clust.mod1$DHSCLUST, agegp = dat.clust.mod1$agecat2,
                    prob.obs.val, prob.pred.val, pred.obs$sd, pred.obs$low, pred.obs$up)
  
  
  #Predict cluster level for age 24-35 months
  dat.clust.mod1 <- subset(dat.clust.val, agecat2 == "24-35 months")
  dat.clust.mod1$age_12_23m2 <- 0  
  dat.clust.mod1$age_24_35m2 <- 1    
  dat.clust.mod1$r.id <- dat.clust.mod1$DHSCLUST
  
  ssamp <- generate(res, dat.clust.mod1, ~ Intercept + x + f.spat, n.samples = nsamples)
  iid.sd <- sqrt(1 / res$summary.hyperpar["Precision for f.iid", 1])
  iid.samp <- matrix(rnorm(nrow(dat.clust.mod1) * nsamples, 0, iid.sd), 
                     nrow = nrow(dat.clust.mod1), ncol = nsamples)
  inv.linpred <- inv.logit(ssamp + iid.samp)
  
  pred.obs <- data.frame(t(apply(inv.linpred, 1, FUN = function(x) { 
    c(mean(x), sd(x), quantile(x, probs = c(0.025, 0.5, 0.975))) 
  })))
  colnames(pred.obs) <- c("mean", "sd", "low", "median", "up")
  
  prob.obs.val <- dat.clust.mod1$prob_obs
  prob.pred.val <- pred.obs$mean
  
  RMSE.val <- sqrt(mean((prob.pred.val - prob.obs.val)^2))
  MAE.val <- mean(abs(prob.pred.val - prob.obs.val))
  avg_bias <- mean(prob.pred.val - prob.obs.val)
  CRPS <- crps(inv.linpred, prob.obs.val)
  
  val.out.24_35[kk, ] <- c(RMSE.val, MAE.val, avg_bias, CRPS)
  
  qp3 <- data.frame(DHSCLUST = dat.clust.mod1$DHSCLUST, agegp = dat.clust.mod1$agecat2,
                    prob.obs.val, prob.pred.val, pred.obs$sd, pred.obs$low, pred.obs$up)
  
  obspred.out <- rbind(obspred.out, qp1, qp2, qp3)
}

colnames(val.out.all)   <- c("bscore")
colnames(val.out.9_11)  <- c("RMSE", "MAE", "avg_bias", "CRPS")
colnames(val.out.12_23) <- c("RMSE", "MAE", "avg_bias", "CRPS")
colnames(val.out.24_35) <- c("RMSE", "MAE", "avg_bias", "CRPS")

write.csv(val.out.9_11,  file = paste0(filePathResult, "MODnosvc_val_out_9_11_strat.csv"))
write.csv(val.out.12_23, file = paste0(filePathResult, "MODnosvc_val_out_12_23_strat.csv"))
write.csv(val.out.24_35, file = paste0(filePathResult, "MODnosvc_val_out_24_35_strat.csv"))

write.csv(val.out.all, file = paste0(filePathResult, "MODnosvc_val_out_all_strat.csv"))
write.csv(obspred.out, file = paste0(filePathResult, "MODnosvc_val_out_obsvpred_all_strat.csv"))




