###MODnosvc

#Set working directory
setwd("/..../")

# Load libraries
library(maps)
library(raster)
library(boot)
library(ggplot2)
library(sf)
library(terra)
library(tidyterra) 
library(tidyr)
library(scales)
library(dplyr)
library(INLA)
library(inlabru)
library(fmesher)

#Set file paths
filePathData <- "Data/"
filePathShp <- "Data/Shape Files/"
filePathRaster <- "Data/Raster Files/"
filePathResult <- "Results/SVC/"

#Loading the data
dat <- read.csv(paste0(filePathData,"data.csv"), header=TRUE)

#Rows of data with at least one missing covariate value
del <- numeric(nrow(dat))
for (i in 1:nrow(dat)){
  if (any(is.na(dat[i,18:29]))) del[i] <- i  
}

#Delete rows with missing covariate values
if (length(which(del!=0))>0) dat <- dat[-which(del!=0),]    
names(dat)

#Names of covariates
covnames <- names(dat)[c(15, 18:29)]


#Model matrix
#Observation points
X0 <- model.matrix(~ -1 + factor(urban1_rural0) + 
                     CIV_MODIS_16day_MidInfr_mean_2017_2021_1km_scaled +
                     civ_avg_wetdays_2017_2021_1km +
                     civ_dst_UCDP_2016_2020_1km +
                     civ_elevation_1km +
                     civ_UrbanAccessibility_2015_1km_filled +
                     civ_2020_walking_tt_1km +
                     civ_avg_malaria_prev_2017_2020_1km +
                     civ_avg_tmax_2017_2021_1km +
                     educ.prop +
                     health_card_doc.prop +
                     media.prop +
                     wealth.prop, 
                   data = dat)

Xobs <-  as.data.frame(X0[,-which(colnames(X0)%in%c("factor(urban1_rural0)0"))])

colnames(Xobs) <- c("urban",
                    "modis_infr",
                    "wetdays",
                    "dst_ucdp",
                    "elevation",
                    "urban_access",
                    "walking_tt",
                    "malaria_prev",
                    "tmax",
                    "educ",
                    "health_card",
                    "media",
                    "wealth")

names(Xobs)

ddata <- data.frame(Xobs, 
                    lon = dat$Longitude, lat = dat$Latitude, 
                    r.id = dat$DHSCLUST,
                    y = dat$received_measles, 
                    n = 1, 
                    age_9_11m2=dat$age_9_11m2,  
                    age_12_23m2=dat$age_12_23m2, 
                    age_24_35m2=dat$age_24_35m2) 

ddata <- na.omit(ddata)
names(ddata)



## Build Mesh
## Read Shape file National Boundary
shp_civ  <- st_read(paste0(filePathShp,"civ_adm0.shp"))
plot(shp_civ)

coords <- dplyr::distinct(data.frame(lon=ddata$lon, lat=ddata$lat))
nrow(coords)

meshfit <- fm_mesh_2d_inla(loc = coords,
                           boundary = shp_civ, 
                           max.edge = c(0.1, 0.5),
                           offset = c(0.1, 0.5),
                           cutoff = 0.1)

meshfit$n 
plot(meshfit)
points(coords, col = "red", pch = 16)

#Convert ddata to an sf object
ddata <- st_as_sf(ddata, coords = c("lon", "lat"), crs = st_crs(shp_civ))

#SPDE object
nu <- 1 # Matern smoothness parameter, redundant here as it implies alpha=2
alpha <- 2

#r0 - this is 5% of the extent of CIV in the north-south direction (i.e. 0.05*(ymax-ymin))
ymax <- max(coords[,2])
ymin <- min(coords[,2])
r0 <- 0.05*(ymax-ymin) 

spde <- inla.spde2.pcmatern(mesh=meshfit, alpha=alpha, prior.range=c(r0, 0.01), prior.sigma=c(3, 0.01))

# Priors
hyper.prec = list(theta = list(prior = "pc.prec", param = c(3,0.01)))
control.fixed = list(mean = 0, prec = 1/1000, mean.intercept = 0, prec.intercept = 1/1000)  

#Formula
components <- ~ Intercept(1) +
  x(cbind(urban,
          modis_infr,
          wetdays,
          dst_ucdp,
          elevation,
          urban_access,
          walking_tt,
          malaria_prev,
          tmax,
          educ,
          health_card,
          media,
          wealth,
          age_12_23m2, 
          age_24_35m2), model = "fixed") +
  #beta_1(geometry, weights= age_12_23m2, model=spde) +
  #beta_2(geometry, weights= age_24_35m2, model=spde) +
  f.spat(geometry, model = spde) +
  f.iid(r.id, model = "iid", hyper = hyper.prec)

# Define the formula for the likelihood
formula <- y ~ .

# Verify dataset structure
print(head(ddata))         
print(names(ddata))        

# Fit the model using inlabru
res <- bru(
  components,
  like(
    formula = formula,
    family = "binomial",
    Ntrials = n,
    data = ddata
  ),
  options = list(
    control.fixed = control.fixed,
    control.compute = list(waic = TRUE, cpo = TRUE, dic = TRUE),
    control.inla = list(int.strategy = "eb"),
    verbose = FALSE
  )
)

# Display the summary of the results
summary(res)


##==============================================================================

#Prediction data
urban1_rural0  <- raster(paste0(filePathRaster,"CIV_urban_rural_1km.tif"))
modis_infr <- raster(paste0(filePathRaster,"CIV_MODIS_16day_MidInfr_mean_2017_2021_1km_scaled.tif"))
wetdays <- raster(paste0(filePathRaster, "civ_avg_wetdays_2017_2021_1km.tif"))
dst_ucdp <- raster(paste0(filePathRaster, "civ_dst_UCDP_2016_2020_1km.tif"))
elevation <- raster(paste0(filePathRaster, "civ_elevation_1km.tif"))
urban_access <- raster(paste0(filePathRaster, "civ_UrbanAccessibility_2015_1km_filled.tif"))
walking_tt <- raster(paste0(filePathRaster, "civ_2020_walking_tt_1km.tif"))
malaria_prev <- raster(paste0(filePathRaster, "civ_avg_malaria_prev_2017_2020_1km.tif"))
tmax <- raster(paste0(filePathRaster, "civ_avg_tmax_2017_2021_1km.tif"))
educ <- raster(paste0(filePathRaster, "civ_educkrig.tif"))
health_card <- raster(paste0(filePathRaster, "civ_health_card_dockrig.tif"))
media <- raster(paste0(filePathRaster, "civ_mediakrig.tif"))
wealth <- raster(paste0(filePathRaster, "civ_wealthkrig.tif"))


urban <- getValues(urban1_rural0)
modis_infr_values <- getValues(modis_infr)
wetdays_values <- getValues(wetdays)
dst_ucdp_values <- getValues(dst_ucdp)
elevation_values <- getValues(elevation)
urban_access_values <- getValues(urban_access)
walking_tt_values <- getValues(walking_tt)
malaria_prev_values <- getValues(malaria_prev)
tmax_values <- getValues(tmax)
educ_values <- getValues(educ)
health_card_values <- getValues(health_card)
media_values <- getValues(media)
wealth_values <- getValues(wealth)


#Prediction coordinates
p.coords <- raster(paste0(filePathRaster,"CIV_urban_rural_1km.tif"))
p.coords <- coordinates(p.coords)

pred_covs <- data.frame(urban, 
                        modis_infr_values,
                        wetdays_values,
                        dst_ucdp_values,
                        elevation_values,
                        urban_access_values,
                        walking_tt_values,
                        malaria_prev_values,
                        tmax_values,
                        educ_values,
                        health_card_values,
                        media_values,
                        wealth_values)

#Predict only for non-missing grid cells
ind <- apply(pred_covs, 1, function(x) any(is.na(x)))
miss    <- which(ind==TRUE)
nonmiss <- which(ind==FALSE)
pred_covs <- pred_covs[nonmiss, ]

#Prediction model matrix
X0 <- model.matrix(~ -1 + factor(urban) + 
                     modis_infr_values +
                     wetdays_values +
                     dst_ucdp_values +
                     elevation_values +
                     urban_access_values +
                     walking_tt_values +
                     malaria_prev_values +
                     tmax_values +
                     educ_values +
                     health_card_values +
                     media_values +
                     wealth_values, data = pred_covs)

Xpred <-  as.data.frame(X0[,-which(colnames(X0)%in%c("factor(urban)0"))])

colnames(Xpred) <- c("urban", 
                     "modis_infr",
                     "wetdays",
                     "dst_ucdp",
                     "elevation",
                     "urban_access",
                     "walking_tt",
                     "malaria_prev",
                     "tmax",
                     "educ",
                     "health_card",
                     "media",
                     "wealth")


## DHSCLUST ID Maximum value
max(unique(dat$DHSCLUST))  ##539


#Generate predictions
#For 9-11m  
dpred <- data.frame(Xpred, lon = p.coords[nonmiss,1], lat = p.coords[nonmiss,2], 
                    age_12_23m2 = 0, 
                    age_24_35m2 = 0,
                    r.id = 540:(539 + nrow(Xpred))  
) 
dpred <- st_as_sf(dpred, coords = c("lon", "lat"), crs = st_crs(shp_civ))

n.samples <- 1000
iid.sd <- sqrt(1/res$summary.hyperpar["Precision for f.iid", 1])
iid.samp <- matrix(rnorm(nrow(dpred)*n.samples, 0, iid.sd), nrow=nrow(dpred), ncol=n.samples)
ssamp <- generate(res, dpred,
                  ~ Intercept + x + f.spat, 
                  n.samples = n.samples)
inv.linpred <- inv.logit(ssamp + iid.samp)

pred.obs <- data.frame(t(apply(inv.linpred, 1, FUN=function(x){ c(mean(x), sd(x), quantile(x, probs=c(0.025,0.5,0.975)))}))) 
colnames(pred.obs) <- c("mean", "sd", "low", "median", "up")

#Example raster layer
n25.p <- raster(paste0(filePathRaster,"CIV_urban_rural_1km.tif"))

#Mean
ll=1:length(ind); ll[nonmiss] = pred.obs$mean; ll[miss] = NA
rr.mean = raster(n25.p); values(rr.mean) = ll

#sd
ll=1:length(ind); ll[nonmiss] = pred.obs$sd; ll[miss] = NA
rr.sd = raster(n25.p); values(rr.sd) = ll

#low
ll=1:length(ind); ll[nonmiss] = pred.obs$low; ll[miss] = NA
rr.low = raster(n25.p); values(rr.low) = ll

#up
ll=1:length(ind); ll[nonmiss] = pred.obs$up; ll[miss] = NA
rr.up = raster(n25.p); values(rr.up) = ll

#median
ll=1:length(ind); ll[nonmiss] = pred.obs$median; ll[miss] = NA
rr.med = raster(n25.p); values(rr.med) = ll

writeRaster(rr.mean, file = paste0(filePathResult, "MODnosvc_vax_mcv1_9_11_mean.tif"), overwrite=TRUE)
writeRaster(rr.sd,   file = paste0(filePathResult, "MODnosvc_vax_mcv1_9_11_sd.tif"), overwrite=TRUE)
writeRaster(rr.low,  file = paste0(filePathResult, "MODnosvc_vax_mcv1_9_11_low.tif"), overwrite=TRUE)
writeRaster(rr.up,   file = paste0(filePathResult, "MODnosvc_vax_mcv1_9_11_up.tif"), overwrite=TRUE)
writeRaster(rr.med,  file = paste0(filePathResult, "MODnosvc_vax_mcv1_9_11_median.tif"), overwrite=TRUE)


#For 12-23m 
dpred <- data.frame(Xpred, lon = p.coords[nonmiss,1], lat = p.coords[nonmiss,2], 
                    age_12_23m2 = 1, 
                    age_24_35m2 = 0,
                    r.id = 540:(539 + nrow(Xpred))  
) 
dpred <- st_as_sf(dpred, coords = c("lon", "lat"), crs = st_crs(shp_civ))

n.samples <- 1000
iid.sd <- sqrt(1/res$summary.hyperpar["Precision for f.iid", 1])
iid.samp <- matrix(rnorm(nrow(dpred)*n.samples, 0, iid.sd), nrow=nrow(dpred), ncol=n.samples)
ssamp <- generate(res, dpred,
                  ~ Intercept + x + f.spat, 
                  n.samples = n.samples)
inv.linpred <- inv.logit(ssamp + iid.samp)

pred.obs <- data.frame(t(apply(inv.linpred, 1, FUN=function(x){ c(mean(x), sd(x), quantile(x, probs=c(0.025,0.5,0.975)))}))) 
colnames(pred.obs) <- c("mean", "sd", "low", "median", "up")

#Example raster layer
n25.p      <- raster(paste0(filePathRaster,"CIV_urban_rural_1km.tif"))

#Mean
ll=1:length(ind); ll[nonmiss] = pred.obs$mean; ll[miss] = NA
rr.mean = raster(n25.p); values(rr.mean) = ll

plot(rr.mean, zlim=c(0,1))

#sd
ll=1:length(ind); ll[nonmiss] = pred.obs$sd; ll[miss] = NA
rr.sd = raster(n25.p); values(rr.sd) = ll

#low
ll=1:length(ind); ll[nonmiss] = pred.obs$low; ll[miss] = NA
rr.low = raster(n25.p); values(rr.low) = ll

#up
ll=1:length(ind); ll[nonmiss] = pred.obs$up; ll[miss] = NA
rr.up = raster(n25.p); values(rr.up) = ll

#median
ll=1:length(ind); ll[nonmiss] = pred.obs$median; ll[miss] = NA
rr.med = raster(n25.p); values(rr.med) = ll

writeRaster(rr.mean, file = paste0(filePathResult, "MODnosvc_vax_mcv1_12_23_mean.tif"), overwrite=TRUE)
writeRaster(rr.sd,   file = paste0(filePathResult, "MODnosvc_vax_mcv1_12_23_sd.tif"), overwrite=TRUE)
writeRaster(rr.low,  file = paste0(filePathResult, "MODnosvc_vax_mcv1_12_23_low.tif"), overwrite=TRUE)
writeRaster(rr.up,   file = paste0(filePathResult, "MODnosvc_vax_mcv1_12_23_up.tif"), overwrite=TRUE)
writeRaster(rr.med,  file = paste0(filePathResult, "MODnosvc_vax_mcv1_12_23_median.tif"), overwrite=TRUE)


#For 24-35m 
dpred <- data.frame(Xpred, lon = p.coords[nonmiss,1], lat = p.coords[nonmiss,2], 
                    age_12_23m2 = 0, 
                    age_24_35m2 = 1,
                    r.id = 540:(539 + nrow(Xpred))  
) 
dpred <- st_as_sf(dpred, coords = c("lon", "lat"), crs = st_crs(shp_civ))

n.samples <- 1000
iid.sd <- sqrt(1/res$summary.hyperpar["Precision for f.iid", 1])
iid.samp <- matrix(rnorm(nrow(dpred)*n.samples, 0, iid.sd), nrow=nrow(dpred), ncol=n.samples)
ssamp <- generate(res, dpred,
                  ~ Intercept + x + f.spat, 
                  n.samples = n.samples)

inv.linpred <- inv.logit(ssamp + iid.samp)    
pred.obs <- data.frame(t(apply(inv.linpred, 1, FUN=function(x){ c(mean(x), sd(x), quantile(x, probs=c(0.025,0.5,0.975)))}))) 
colnames(pred.obs) <- c("mean", "sd", "low", "median", "up")

#Example raster layer
n25.p      <- raster(paste0(filePathRaster,"CIV_urban_rural_1km.tif"))

#Mean
ll=1:length(ind); ll[nonmiss] = pred.obs$mean; ll[miss] = NA
rr.mean = raster(n25.p); values(rr.mean) = ll

plot(rr.mean, zlim=c(0,1))

#sd
ll=1:length(ind); ll[nonmiss] = pred.obs$sd; ll[miss] = NA
rr.sd = raster(n25.p); values(rr.sd) = ll

#low
ll=1:length(ind); ll[nonmiss] = pred.obs$low; ll[miss] = NA
rr.low = raster(n25.p); values(rr.low) = ll

#up
ll=1:length(ind); ll[nonmiss] = pred.obs$up; ll[miss] = NA
rr.up = raster(n25.p); values(rr.up) = ll

#median
ll=1:length(ind); ll[nonmiss] = pred.obs$median; ll[miss] = NA
rr.med = raster(n25.p); values(rr.med) = ll

writeRaster(rr.mean, file = paste0(filePathResult, "MODnosvc_vax_mcv1_24_35_mean.tif"), overwrite=TRUE)
writeRaster(rr.sd,   file = paste0(filePathResult, "MODnosvc_vax_mcv1_24_35_sd.tif"), overwrite=TRUE)
writeRaster(rr.low,  file = paste0(filePathResult, "MODnosvc_vax_mcv1_24_35_low.tif"), overwrite=TRUE)
writeRaster(rr.up,   file = paste0(filePathResult, "MODnosvc_vax_mcv1_24_35_up.tif"), overwrite=TRUE)
writeRaster(rr.med,  file = paste0(filePathResult, "MODnosvc_vax_mcv1_24_35_median.tif"), overwrite=TRUE)



