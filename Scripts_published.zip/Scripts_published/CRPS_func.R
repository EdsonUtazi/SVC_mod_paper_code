crps<-function(xits,xval){
   ## xits is the mcmc samples with dim n x its
   ## xval is the actual obs.
   tmp<-cbind(xval,xits)
   tmp<-na.omit(tmp)
   its<-length(tmp[1,])-1
   fnc<-function(p,n){
     out<-NULL
     out1<-NULL
     for(i in 1:n){
     out[i]<-abs(p[i+1]-p[1])
#out1[i]<-abs(p[i+1]-sample(p[-c(1,i)],1))*abs(p[i+1]-sample(p[-c(1,i)],1))
     out1[i]<-sum(abs(p[i+1]-p[-1]))
     }
     out<-sum(out)/n
     out1<-sum(out1)/(2*n*n)
     out<-out-out1
     out
   }
   tmp<-apply(tmp,1,fnc,its)
   tmp<-mean(tmp)
   tmp
}
